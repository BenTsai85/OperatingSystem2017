#include "syscall.h"

main()
        {
                int     n;
                for (n=5;n<=9;n++) {
			Sleep(n);
                        PrintInt(n);
		}
        }
