
#ifndef FRAMEINFO_H
#define FRAMEINFO_H

#include "copyright.h"
#include "utility.h"

class FrameInfoEntry {
public:
    bool valid;			// if being used
    // bool lock;
    void* addrspace;		// which process is using this entry
    unsigned int vpn;		// which virtual page of the process is stored in this page
    unsigned int LRU_time;	// time record for LRU_time
    unsigned int LFU_times;	// times record for LFU_time
};

#endif
