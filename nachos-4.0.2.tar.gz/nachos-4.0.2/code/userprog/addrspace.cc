// addrspace.cc 
//	Routines to manage address spaces (executing user programs).
//
//	In order to run a user program, you must:
//
//	1. link with the -n -T 0 option 
//	2. run coff2noff to convert the object file to Nachos format
//		(Nachos object code format is essentially just a simpler
//		version of the UNIX executable object code format)
//	3. load the NOFF file into the Nachos file system
//		(if you haven't implemented the file system yet, you
//		don't need to do this last step)
//
// Copyright (c) 1992-1996 The Regents of the University of California.
// All rights reserved.  See copyright.h for copyright notice and limitation 
// of liability and disclaimer of warranty provisions.

#include "copyright.h"
#include "main.h"
#include "addrspace.h"
#include "machine.h"
#include "../bin/noff.h"

//----------------------------------------------------------------------
// SwapHeader
// 	Do little endian to big endian conversion on the bytes in the 
//	object file header, in case the file was generated on a little
//	endian machine, and we're now running on a big endian machine.
//----------------------------------------------------------------------

static void 
SwapHeader (NoffHeader *noffH)
{
    noffH->noffMagic = WordToHost(noffH->noffMagic);
    noffH->code.size = WordToHost(noffH->code.size);
    noffH->code.virtualAddr = WordToHost(noffH->code.virtualAddr);
    noffH->code.inFileAddr = WordToHost(noffH->code.inFileAddr);
    noffH->initData.size = WordToHost(noffH->initData.size);
    noffH->initData.virtualAddr = WordToHost(noffH->initData.virtualAddr);
    noffH->initData.inFileAddr = WordToHost(noffH->initData.inFileAddr);
    noffH->uninitData.size = WordToHost(noffH->uninitData.size);
    noffH->uninitData.virtualAddr = WordToHost(noffH->uninitData.virtualAddr);
    noffH->uninitData.inFileAddr = WordToHost(noffH->uninitData.inFileAddr);
}

//----------------------------------------------------------------------
// AddrSpace::AddrSpace
// 	Create an address space to run a user program.
//	Set up the translation from program memory to physical 
//	memory.  For now, this is really simple (1:1), since we are
//	only uniprogramming, and we have a single unsegmented page table
//----------------------------------------------------------------------

AddrSpace::AddrSpace()
{
/*    pageTable = new TranslationEntry[NumPhysPages];
    for (unsigned int i = 0; i < NumPhysPages; i++) {
	pageTable[i].virtualPage = i;	// for now, virt page # = phys page #
	pageTable[i].physicalPage = i;
//	pageTable[i].physicalPage = 0;
	pageTable[i].valid = TRUE;
//	pageTable[i].valid = FALSE;
	pageTable[i].use = FALSE;
	pageTable[i].dirty = FALSE;
	pageTable[i].readOnly = FALSE;  
    }
*/    
    // zero out the entire address space
//    bzero(kernel->machine->mainMemory, MemorySize);
}

//----------------------------------------------------------------------
// AddrSpace::~AddrSpace
// 	Dealloate an address space.
//----------------------------------------------------------------------

AddrSpace::~AddrSpace()
{
   delete pageTable;
}

//----------------------------------------------------------------------
// AddrSpace::Load
// 	Load a user program into memory from a file.
//
//	Assumes that the page table has been initialized, and that
//	the object code file is in NOFF format.
//
//	"fileName" is the file containing the object code to load into memory
//----------------------------------------------------------------------

bool 
AddrSpace::Load(char *fileName) 
{
    OpenFile *executable = kernel->fileSystem->Open(fileName);
    NoffHeader noffH;
    unsigned int size;

    if (executable == NULL) {
	cerr << "Unable to open file " << fileName << "\n";
	return FALSE;
    }
    executable->ReadAt((char *)&noffH, sizeof(noffH), 0);
    if ((noffH.noffMagic != NOFFMAGIC) && 
		(WordToHost(noffH.noffMagic) == NOFFMAGIC))
    	SwapHeader(&noffH);
    ASSERT(noffH.noffMagic == NOFFMAGIC);

    codeVirtAddr = noffH.code.virtualAddr;
    uninitVirtAddr = noffH.uninitData.virtualAddr;
    uninitPhysAddr = noffH.code.size;
    initVirtAddr = noffH.initData.virtualAddr > uninitVirtAddr ? noffH.initData.virtualAddr : -1;
    initPhysAddr = noffH.uninitData.size + uninitPhysAddr;
    unsigned int stackPhysAddr = noffH.initData.size + initPhysAddr;


// how big is address space?
    numPages = divRoundUp(UserStackSize + stackPhysAddr, PageSize);

    pageTable = new TranslationEntry[numPages];

    for (unsigned int i = 0; i < numPages; ++i) {
        int j = 0;	// index of frameTable
        while (kernel->machine->frameTable[j].valid && j < NumPhysPages)
	    ++j;
	pageTable[i].dirty = FALSE;
        pageTable[i].use = FALSE;
        pageTable[i].readOnly = false;
        pageTable[i].virtualPage = i;
        if (j < NumPhysPages) {
            pageTable[i].physicalPage = j;
            pageTable[i].valid = true;

            kernel->machine->frameTable[j].valid = true;
            kernel->machine->frameTable[j].addrspace = (void*)this;
            kernel->machine->frameTable[j].vpn = i;
            if (kernel->machine->pageReplacementType == LRU) {
                kernel->machine->frameTable[j].LRU_time = 0;
            }
            else if (kernel->machine->pageReplacementType == LFU) {
                kernel->machine->frameTable[j].LFU_Times = 0;
            }
            if (noffH.code.size > 0) {
                if (i * PageSize < uninitPhysAddr) {
                    if ((i + 1) * PageSize > uninitPhysAddr) {
                        int diff = uninitPhysAddr - i * PageSize;
                        executable->ReadAt(&(kernel->machine->mainMemory[j * PageSize]), diff, noffH.code.inFileAddr + i * PageSize);
                    }
                    else {
                        executable->ReadAt(&(kernel->machine->mainMemory[j * PageSize]), PageSize, noffH.code.inFileAddr + i * PageSize);
                    }
                }
            }
            if (noffH.initData.size > 0) {
                if (i * PageSize < stackPhysAddr && i * PageSize >= initPhysAddr) {
                    if ((i + 1) * PageSize > stackPhysAddr) {
                        int diff = stackPhysAddr - i * PageSize;
                        if (diff > noffH.initData.size) {
                            executable->ReadAt(&(kernel->machine->mainMemory[j * PageSize + diff - noffH.initData.size]), noffH.initData.size, noffH.initData.inFileAddr);
                        }
                        else {
                            executable->ReadAt(&(kernel->machine->mainMemory[j * PageSize]), diff, noffH.initData.inFileAddr + i * PageSize - initPhysAddr);
                        }
                    }
                    else {
                        executable->ReadAt(&(kernel->machine->mainMemory[j * PageSize]), PageSize, noffH.initData.inFileAddr + i * PageSize - initPhysAddr);
                    }
                }
                if (i * PageSize < initPhysAddr && (i + 1) * PageSize > initPhysAddr) {
                    int diff = initPhysAddr - i * PageSize;
                    executable->ReadAt(&(kernel->machine->mainMemory[(j + 1) * PageSize - diff]), diff < noffH.initData.size ? diff : noffH.initData.size, noffH.initData.inFileAddr);
                }
            }
        }
        else {
            int k = 0;	// index of swapTable
            while (kernel->machine->swapTable[k].valid)
                ++k;
            pageTable[i].physicalPage = k;
            pageTable[i].valid = false;

            kernel->machine->swapTable[k].valid = true;
            kernel->machine->swapTable[k].addrspace = (void*)this;
            kernel->machine->swapTable[k].vpn = i;
            if (kernel->machine->pageReplacementType == LRU) {
                kernel->machine->swapTable[k].LRU_time = 0;
            }
            else if (kernel->machine->pageReplacementType == LFU) {
                kernel->machine->swapTable[k].LFU_Times = 0;
            }
            char* buff = new char [ PageSize ];
            if (noffH.code.size > 0) {
                if (i * PageSize < uninitPhysAddr) {
                    if ((i + 1) * PageSize > uninitPhysAddr) {
                        int diff = uninitPhysAddr - i * PageSize;
                        executable->ReadAt(buff, diff, noffH.code.inFileAddr + i * PageSize);
                    }
                    else {
                        executable->ReadAt(buff, PageSize, noffH.code.inFileAddr + i * PageSize);
                    }
                }
            }
            if (noffH.initData.size > 0) {
                if (i * PageSize < stackPhysAddr && i * PageSize >= initPhysAddr) {
                    if ((i + 1) * PageSize > stackPhysAddr) {
                        int diff = stackPhysAddr - i * PageSize;
                        if (diff > noffH.initData.size) {
                            executable->ReadAt(buff + diff - noffH.initData.size, noffH.initData.size, noffH.initData.inFileAddr);
                        }
                        else {
                            executable->ReadAt(buff, diff, noffH.initData.inFileAddr + i * PageSize - initPhysAddr);
                        }
                    }
                    else {
                        executable->ReadAt(buff, PageSize, noffH.initData.inFileAddr + i * PageSize - initPhysAddr);
                    }
                }
                if (i * PageSize < initPhysAddr && (i + 1) * PageSize > initPhysAddr) {
                    int diff = initPhysAddr - i * PageSize;
                    executable->ReadAt(buff + PageSize - diff, diff < noffH.initData.size ? diff : noffH.initData.size, noffH.initData.inFileAddr);
                }
            }
            kernel->synchDisk->WriteSector(k, buff);
            delete buff;
        }
    }

    cout << "number of pages of " << fileName<< " is "<<numPages<<endl;
    size = numPages * PageSize;

    // ASSERT(numPages <= NumPhysPages);		// check we're not trying
						// to run anything too big --
						// at least until we have
						// virtual memory

    DEBUG(dbgAddr, "Initializing address space: " << numPages << ", " << size);

    delete executable;			// close file
    return TRUE;			// success
}

//----------------------------------------------------------------------
// AddrSpace::Execute
// 	Run a user program.  Load the executable into memory, then
//	(for now) use our own thread to run it.
//
//	"fileName" is the file containing the object code to load into memory
//----------------------------------------------------------------------

void 
AddrSpace::Execute(char *fileName) 
{
    if (!Load(fileName)) {
	cout << "inside !Load(FileName)" << endl;
	return;				// executable not found
    }

    //kernel->currentThread->space = this;
    this->InitRegisters();		// set the initial register values
    this->RestoreState();		// load page table register

    kernel->machine->Run();		// jump to the user progam

    ASSERTNOTREACHED();			// machine->Run never returns;
					// the address space exits
					// by doing the syscall "exit"
}


//----------------------------------------------------------------------
// AddrSpace::InitRegisters
// 	Set the initial values for the user-level register set.
//
// 	We write these directly into the "machine" registers, so
//	that we can immediately jump to user code.  Note that these
//	will be saved/restored into the currentThread->userRegisters
//	when this thread is context switched out.
//----------------------------------------------------------------------

void
AddrSpace::InitRegisters()
{
    Machine *machine = kernel->machine;
    int i;

    for (i = 0; i < NumTotalRegs; i++)
	machine->WriteRegister(i, 0);

    // Initial program counter -- must be location of "Start"
    machine->WriteRegister(PCReg, 0);	

    // Need to also tell MIPS where next instruction is, because
    // of branch delay possibility
    machine->WriteRegister(NextPCReg, 4);

   // Set the stack register to the end of the address space, where we
   // allocated the stack; but subtract off a bit, to make sure we don't
   // accidentally reference off the end!
    machine->WriteRegister(StackReg, numPages * PageSize - 16);
    DEBUG(dbgAddr, "Initializing stack pointer: " << numPages * PageSize - 16);
}

//----------------------------------------------------------------------
// AddrSpace::SaveState
// 	On a context switch, save any machine state, specific
//	to this address space, that needs saving.
//
//	For now, don't need to save anything!
//----------------------------------------------------------------------

void AddrSpace::SaveState() 
{/*
    if (kernel->machine->pageTable) {
        pageTable=kernel->machine->pageTable;
        numPages=kernel->machine->pageTableSize;
        codeVirtAddr = kernel->machine->codeVirtAddr;
        initVirtAddr = kernel->machine->initVirtAddr;
        initPhysAddr = kernel->machine->initPhysAddr;
        uninitVirtAddr = kernel->machine->uninitVirtAddr;
        uninitPhysAddr = kernel->machine->uninitPhysAddr;
    }*/
}

//----------------------------------------------------------------------
// AddrSpace::RestoreState
// 	On a context switch, restore the machine state so that
//	this address space can run.
//
//      For now, tell the machine where to find the page table.
//----------------------------------------------------------------------

void AddrSpace::RestoreState() 
{
    kernel->machine->pageTable = pageTable;
    kernel->machine->pageTableSize = numPages;
    kernel->machine->codeVirtAddr = codeVirtAddr;
    kernel->machine->initVirtAddr = initVirtAddr;
    kernel->machine->initPhysAddr = initPhysAddr;
    kernel->machine->uninitVirtAddr = uninitVirtAddr;
    kernel->machine->uninitPhysAddr = uninitPhysAddr;
 
}
